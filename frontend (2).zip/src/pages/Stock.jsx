import React, { useEffect, useState } from "react";

import { Button } from "../components/ui/button";
import { Card, CardContent } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../components/ui/dialog";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "../components/ui/select";
import { Sidebar } from "../components/Sidebar"
import { Navbar } from "../components/Navbar"

const unitOptions = ["ml", "L", "g", "kg", "unit"];

export default function Stock() {
  // Cache for ingredient details by id
  const [stockItems, setStockItems] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    ingredientId: "",
    purchased_quantity: "",
    unit: "",
    purchase_price: "",
    waste_percent: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [editingStock, setEditingStock] = useState(null);
  const [formErrors, setFormErrors] = useState({});
  const [ingredients, setIngredients] = useState([]);
  const [message, setMessage] = useState("");
  const [messageType, setMessageType] = useState("");

  useEffect(() => {
    fetchIngredients();
    fetchStock();
  }, []);

  const fetchIngredients = async () => {
    try {
      const token = localStorage.getItem("accessToken");
      const res = await fetch("http://localhost:3000/ingredients", {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setIngredients(Array.isArray(data) ? data : []);
      } else {
        setIngredients([]);
      }
    } catch (err) {
      setIngredients([]);
    }
  };

  const fetchStock = async () => {
    setIsLoading(true);
    try {
      const token = localStorage.getItem("accessToken");
      const res = await fetch("http://localhost:3000/stock", {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setStockItems(Array.isArray(data) ? data : []);
      } else {
        setStockItems([]);
      }
    } catch (err) {
      setStockItems([]);
    }
    setIsLoading(false);
  };

  const handleDelete = async (id) => {
    setIsSubmitting(true);
    setMessage("");
    try {
      const token = localStorage.getItem("accessToken");
      const res = await fetch(`http://localhost:3000/stock/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        setMessage("Stock deleted successfully.");
        setMessageType("success");
        fetchStock();
      } else {
        setMessage("Failed to delete stock.");
        setMessageType("error");
      }
    } catch (err) {
      setMessage("Error deleting stock.");
      setMessageType("error");
    }
    setIsSubmitting(false);
  };

  const handleEdit = (item) => {
    setEditingStock(item.id);
    setFormData({
      ingredientId: item.ingredient?.id || "",
      purchased_quantity: item.purchased_quantity,
      unit: item.unit,
      purchase_price: item.purchase_price,
      waste_percent: item.waste_percent
    });
    setShowModal(true);
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    setMessage("");
    let errors = {};
    if (!formData.ingredientId) errors.ingredientId = "Required";
    if (!formData.purchased_quantity) errors.purchased_quantity = "Required";
    if (!formData.unit) errors.unit = "Required";
    if (!formData.purchase_price) errors.purchase_price = "Required";
    if (!formData.waste_percent) errors.waste_percent = "Required";
    setFormErrors(errors);
    if (Object.keys(errors).length) {
      setIsSubmitting(false);
      return;
    }
    try {
      const token = localStorage.getItem("accessToken");
      let res;
      if (editingStock) {
        const payload = {
          purchased_quantity: Number(formData.purchased_quantity),
          unit: formData.unit,
          purchase_price: Number(formData.purchase_price),
          waste_percent: Number(formData.waste_percent),
          ingredientId: formData.ingredientId
        };
        res = await fetch(`http://localhost:3000/stock/${editingStock}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
          body: JSON.stringify(payload)
        });
      } else {
        const payload = {
          purchased_quantity: Number(formData.purchased_quantity),
          unit: formData.unit,
          purchase_price: Number(formData.purchase_price),
          waste_percent: Number(formData.waste_percent),
          ingredientId: formData.ingredientId
        };
        res = await fetch("http://localhost:3000/stock", {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
          body: JSON.stringify(payload)
        });
      }
      if (res.ok) {
        setMessage(editingStock ? "Stock updated successfully." : "Stock added successfully.");
        setMessageType("success");
        setShowModal(false);
        setEditingStock(null);
        setFormData({ ingredientId: "", purchased_quantity: "", unit: "", purchase_price: "", waste_percent: "" });
        fetchStock();
      } else {
        const errorText = await res.text();
        setMessage(`Failed to submit stock. ${errorText}`);
        setMessageType("error");
      }
    } catch (err) {
      setMessage("Error submitting stock.");
      setMessageType("error");
    }
    setIsSubmitting(false);
  };

  return (
 <div className="min-h-screen bg-gradient-to-br bg-white ">
            <Sidebar />
            <div className="md:pl-64 flex flex-col min-h-screen">
              <Navbar />
              <main className="flex-1 p-4 sm:p-6 space-y-6">
          <div className="max-w-5xl mx-auto">
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-3xl font-bold text-amber-900">Stock Management</h1>
              <Button onClick={() => { setShowModal(true); setEditingStock(null); setFormData({ ingredientId: "", purchased_quantity: "", unit: "", purchase_price: "", waste_percent: "" }); }}>Add Stock</Button>
            </div>
            <Card className="bg-white/90 border-amber-100">
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-amber-100/50 border-b">
                      <tr>
                        <th className="p-4 text-left">Ingredient Name</th>
                        <th className="p-4 text-right">Quantity</th>
                        <th className="p-4 text-left">Unit</th>
                        <th className="p-4 text-right">Purchase Price ($)</th>
                        <th className="p-4 text-right">Waste %</th>
                        <th className="p-4 text-center">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {isLoading ? (
                        <tr><td colSpan={6} className="p-4 text-center">Loading...</td></tr>
                      ) : stockItems.length === 0 ? (
                        <tr><td colSpan={6} className="p-4 text-center">No stock found.</td></tr>
                      ) : stockItems.map(item => (
                        <tr key={item.id} className="border-b">
                          <td className="p-4">{item.ingredient?.name || "Unknown Ingredient"}</td>
                          <td className="p-4 text-right">{item.purchased_quantity}</td>
                          <td className="p-4">{item.unit}</td>
                          <td className="p-4 text-right">${Number(item.purchase_price).toFixed(2)}</td>
                          <td className="p-4 text-right">{item.waste_percent}%</td>
                          <td className="p-4 text-center">
                            <Button size="sm" variant="outline" onClick={() => handleEdit(item)} disabled={isSubmitting}>Edit</Button>
                           
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
            {message && (
              <div className={`mb-4 px-4 py-2 rounded text-sm ${messageType === "success" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}>
                {message}
              </div>
            )}
            <Dialog open={showModal} onOpenChange={open => !open && setShowModal(false)}>
              <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto bg-white/95 border-amber-100">
                <DialogHeader>
                  <DialogTitle className="text-amber-900 text-xl">{editingStock ? "Edit Stock" : "Add Stock"}</DialogTitle>
                </DialogHeader>
                <div className="space-y-5 py-4">
                  <div className="flex gap-4 items-center">
                    <div className="flex-1">
                      <Label htmlFor="ingredientId" className="text-amber-900 font-medium">Ingredient *</Label>
                      <Select
                        value={editingStock ? (stockItems.find(s => s.id === editingStock)?.ingredient?.id || "") : formData.ingredientId}
                        onValueChange={value => {
                          if (!editingStock) {
                            setFormData(prev => ({ ...prev, ingredientId: value }));
                          }
                        }}
                        disabled={!!editingStock}
                      >
                        <SelectTrigger className={`mt-1 ${formErrors.ingredientId ? "border-red-500" : "border-amber-200 focus:ring-amber-500"}`}>
                          <SelectValue placeholder="Select ingredient" />
                        </SelectTrigger>
                        <SelectContent>
                          {ingredients.map(ingredient => (
                            <SelectItem key={ingredient.id} value={ingredient.id}>{ingredient.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {formErrors.ingredientId && <p className="text-red-500 text-xs mt-1">{formErrors.ingredientId}</p>}
                    </div>
                    <div className="flex-1">
                      <Label htmlFor="purchased_quantity" className="text-amber-900 font-medium">Quantity *</Label>
                      <Input
                        id="purchased_quantity"
                        type="number"
                        step="1"
                        value={formData.purchased_quantity}
                        onChange={e => setFormData(prev => ({ ...prev, purchased_quantity: e.target.value }))}
                        placeholder="e.g., 100"
                        className={`mt-1 ${formErrors.purchased_quantity ? "border-red-500" : "border-amber-200 focus:ring-amber-500"}`}
                      />
                      {formErrors.purchased_quantity && <p className="text-red-500 text-xs mt-1">{formErrors.purchased_quantity}</p>}
                    </div>
                  </div>
                  <div className="flex gap-4 items-center">
                    <div className="flex-1">
                      <Label htmlFor="unit" className="text-amber-900 font-medium">Unit *</Label>
                      <Select value={formData.unit} onValueChange={value => setFormData(prev => ({ ...prev, unit: value }))}>
                        <SelectTrigger className={`mt-1 ${formErrors.unit ? "border-red-500" : "border-amber-200 focus:ring-amber-500"}`}>
                          <SelectValue placeholder="Select unit" />
                        </SelectTrigger>
                        <SelectContent>
                          {unitOptions.map(unit => (
                            <SelectItem key={unit} value={unit}>{unit}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {formErrors.unit && <p className="text-red-500 text-xs mt-1">{formErrors.unit}</p>}
                    </div>
                    <div className="flex-1">
                      <Label htmlFor="purchase_price" className="text-amber-900 font-medium">Purchase Price ($) *</Label>
                      <Input
                        id="purchase_price"
                        type="number"
                        step="0.01"
                        value={formData.purchase_price}
                        onChange={e => setFormData(prev => ({ ...prev, purchase_price: e.target.value }))}
                        placeholder="e.g., 0.84"
                        className={`mt-1 ${formErrors.purchase_price ? "border-red-500" : "border-amber-200 focus:ring-amber-500"}`}
                      />
                      {formErrors.purchase_price && <p className="text-red-500 text-xs mt-1">{formErrors.purchase_price}</p>}
                    </div>
                    <div className="flex-1">
                      <Label htmlFor="waste_percent" className="text-amber-900 font-medium">Waste % *</Label>
                      <Input
                        id="waste_percent"
                        type="number"
                        step="0.1"
                        value={formData.waste_percent}
                        onChange={e => setFormData(prev => ({ ...prev, waste_percent: e.target.value }))}
                        placeholder="e.g., 10"
                        className={`mt-1 ${formErrors.waste_percent ? "border-red-500" : "border-amber-200 focus:ring-amber-500"}`}
                      />
                      {formErrors.waste_percent && <p className="text-red-500 text-xs mt-1">{formErrors.waste_percent}</p>}
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setShowModal(false)} disabled={isSubmitting}>Cancel</Button>
                  <Button onClick={handleSubmit} disabled={isSubmitting} className="bg-amber-600 hover:bg-amber-700 flex items-center gap-2">
                    {isSubmitting && <span className="animate-spin h-4 w-4 border-2 border-t-amber-900 border-amber-300 rounded-full inline-block"></span>}
                    {isSubmitting ? "Processing..." : editingStock ? "Update" : "Add"} Stock
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </main>
      </div>
    </div>
  );
}